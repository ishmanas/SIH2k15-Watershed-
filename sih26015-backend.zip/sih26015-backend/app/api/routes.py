from fastapi import APIRouter, HTTPException

from app.models.schemas import AnalysisRequest
from app.services.earth_engine import calculate_indices, get_tile_url

router = APIRouter()

NDVI_VIS = {"min": -0.2, "max": 0.8, "palette": ["brown", "yellow", "green"]}
NDWI_VIS = {"min": -0.5, "max": 0.5, "palette": ["white", "lightblue", "blue"]}


@router.get("/")
def home():
    return {"message": "SIH26015 Geospatial Analysis API", "status": "running"}


@router.post("/analyze")
def analyze(request: AnalysisRequest):
    try:
        result = calculate_indices(
            latitude=request.latitude,
            longitude=request.longitude,
            start_date=request.start_date,
            end_date=request.end_date,
            radius_meters=request.radius_meters,
        )

        ndvi_map = result["ndvi"].getMapId(NDVI_VIS)
        ndwi_map = result["ndwi"].getMapId(NDWI_VIS)

        return {
            "status": "success",
            "image_count": result["image_count"],
            "center": {"lat": request.latitude, "lon": request.longitude},
            "ndvi": {
                "mapid": ndvi_map["mapid"],
                "token": ndvi_map.get("token", ""),
                "tile_url": get_tile_url(ndvi_map),
            },
            "ndwi": {
                "mapid": ndwi_map["mapid"],
                "token": ndwi_map.get("token", ""),
                "tile_url": get_tile_url(ndwi_map),
            },
            "analysis": result["analysis"],
        }

    except ValueError as e:
        # Expected "no imagery found" case -> 404, not a server crash
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
