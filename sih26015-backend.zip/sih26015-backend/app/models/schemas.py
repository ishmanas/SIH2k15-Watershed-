from pydantic import BaseModel, Field


class AnalysisRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    start_date: str  # "YYYY-MM-DD"
    end_date: str    # "YYYY-MM-DD"
    radius_meters: int = 5000


class LayerInfo(BaseModel):
    mapid: str
    token: str
    tile_url: str


class AnalysisResponse(BaseModel):
    status: str
    image_count: int
    center: dict
    ndvi: LayerInfo
    ndwi: LayerInfo
    analysis: dict
