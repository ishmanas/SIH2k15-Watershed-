from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router
from app.services.earth_engine import initialize_earth_engine

app = FastAPI(
    title="SIH26015 Geospatial Analysis API",
    description="Backend for watershed development using geo-coded images + GEE satellite analysis.",
    version="1.0",
)

# Wide open CORS for the hackathon demo -- fine for today, tighten later if needed
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup_event():
    initialize_earth_engine()


app.include_router(router)
