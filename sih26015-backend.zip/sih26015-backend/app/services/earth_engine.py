import ee


def initialize_earth_engine():
    """Initialize Google Earth Engine. Call once on app startup."""
    try:
        ee.Initialize()
    except Exception:
        ee.Authenticate()
        ee.Initialize()


def create_geometry(latitude: float, longitude: float, radius_meters: int = 5000):
    """Create a circular area of interest around the selected location."""
    point = ee.Geometry.Point([longitude, latitude])
    return point.buffer(radius_meters)


def get_sentinel_collection(geometry, start_date: str, end_date: str):
    """Get cloud-filtered Sentinel-2 Surface Reflectance imagery."""
    return (
        ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
        .filterBounds(geometry)
        .filterDate(start_date, end_date)
        .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", 20))
    )


def classify_value(value, low_thresh, high_thresh):
    if value is None:
        return "Unknown"
    if value < low_thresh:
        return "Low"
    if value < high_thresh:
        return "Moderate"
    return "High"


def calculate_indices(latitude: float, longitude: float, start_date: str, end_date: str, radius_meters: int = 5000):
    geometry = create_geometry(latitude, longitude, radius_meters)
    collection = get_sentinel_collection(geometry, start_date, end_date)

    image_count = collection.size().getInfo()
    if image_count == 0:
        raise ValueError(
            "No cloud-free Sentinel-2 images found for this location/date range. "
            "Try widening the date range or increasing the cloud threshold."
        )

    image = collection.median().clip(geometry)

    red = image.select("B4")
    green = image.select("B3")
    nir = image.select("B8")

    ndvi = nir.subtract(red).divide(nir.add(red)).rename("NDVI")
    ndwi = green.subtract(nir).divide(green.add(nir)).rename("NDWI")

    # Mean values over the area, for a quick numeric summary / classification
    stats = ndvi.addBands(ndwi).reduceRegion(
        reducer=ee.Reducer.mean(),
        geometry=geometry,
        scale=30,
        maxPixels=1e9,
    ).getInfo()

    ndvi_mean = stats.get("NDVI")
    ndwi_mean = stats.get("NDWI")

    analysis = {
        "ndvi_mean": round(ndvi_mean, 4) if ndvi_mean is not None else None,
        "ndwi_mean": round(ndwi_mean, 4) if ndwi_mean is not None else None,
        "vegetation": classify_value(ndvi_mean, 0.2, 0.5),
        "water_moisture": classify_value(ndwi_mean, -0.1, 0.1),
    }

    return {
        "ndvi": ndvi,
        "ndwi": ndwi,
        "geometry": geometry,
        "image_count": image_count,
        "analysis": analysis,
    }


def get_tile_url(mapid_dict):
    """Build a standard XYZ tile URL template Leaflet/Mapbox/MapLibre can consume directly."""
    return mapid_dict["tile_fetcher"].url_format
